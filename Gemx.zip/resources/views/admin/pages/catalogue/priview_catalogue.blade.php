<div class="container demo">

    <div class="modal left fade" id="priviewmodel" tabindex="" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog priview-diloge" role="document">
            <div class="modal-content">
                <div class="modal-header ">
                    <h5 class="modal-title" id="exampleModalLabel" style="font-size: 16px;">Choose a template for presentation</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="nav flex-sm-column flex-row">
                        <p>Select the number of Products per slide</p>
                        <div id="exTab3" >
                                <div class="row">
                                   <div class="col-md-12">
                                    <ul class="sidenav nav-pills d-flex justify-content-between w-100 text-left list-inline  popupnavbar" >
                                        <li class="active">
                                            <a href="#1b" data-toggle="tab" id="tab1">1</a>
                                        </li>
                                        <li><a href="#2b" data-toggle="tab" id="tab2">2</a>
                                        </li>
                                        <li><a href="#3b" data-toggle="tab" id="tab3">3</a>
                                        </li>
                                        <li><a href="#4b" data-toggle="tab" id="tab4">4</a>
                                        </li>
                                        <li><a href="#5b" data-toggle="tab" id="tab5">5</a>
                                        </li>

                                    </ul>
                                   </div>

                                    <div class="col-md-12">
                                        <div class="tab-content clearfix">
                                            <div class="tab-pane sapestebpanr active" id="1b">
                                              
                                                <div class="row  pt-1 pb-1">
                                                    <div class="col-lg-6">
                                                        <div class="d-flex w-100 h-100 bg-white jumbotron flex-column text-info text-center justify-content-between imgshape1">
                                                            <i class="fa-regular fa-image"></i>
                                                            <p>Main Photo</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="d-flex jumbotron flex-column text-info text-center justify-content-around w-100 imgshape bg-white">
                                                            <i class="fa-regular fa-image " style="font-size: 31px;
                                                            color: #a7a7a7;"></i>
                                                            <p>Secondary Photo</p>
                                                        </div>
                                                        <div class="detail w-100 bg-white  pl-3 pt-4 imgshape">
                                                            <table>
                                                               <tbody style="font-size: 9px;">
                                                                <tr>
                                                                   <td >
                                                                    <strong> Name: </strong> Kangan
                                                                   </td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Group: </strong> Gold</td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Category: </strong> Gold Categary</td>
                                                                </tr>
                                                               
                                                                <tr>
                                                                    <td>
                                                                        <strong> Selling Price: </strong> $22
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Purchase Price: </strong> $30</td>
                                                                </tr>
                                                               </tbody>
                                                            
                                                            </table>
                                                           
                                                           
                                                        </div>
                                                    </div>
                                                </div>
                                               
                                            </div>
                                            <div class="tab-pane sapestebpanr " id="2b">
                                               
                                                <div class="row  pt-1 pb-1">
                                                    <div class="col-lg-6">
                                                        <div class="d-flex jumbotron flex-column text-info text-center justify-content-around w-100 imgshape bg-white">
                                                            <i class="fa-regular fa-image " style="font-size: 31px;
                                                            color: #a7a7a7;"></i>
                                                        <p>Main Photo</p>
                                                       </div>
                                                       <div class="detail w-100 bg-white  pl-3 pt-4 imgshape">
                                                        <table>
                                                           <tbody style="font-size: 9px;">
                                                                <tr>
                                                                   <td>
                                                                    <strong> Name: </strong> Kangan
                                                                   </td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Group: </strong>Gold</td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Category: </strong> Gold Category</td>
                                                                </tr>
                                                               
                                                                <tr>
                                                                    <td>
                                                                        <strong> Selling Price: </strong> $22
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Purchase Price: </strong> $30</td>
                                                                </tr>
                                                               </tbody>
                                                            
                                                            </table>
                                                           
                                                           
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="d-flex w-100 h-100 bg-white jumbotron flex-column text-info text-center justify-content-between imgshape1">
                                                            <i class="fa-regular fa-image"></i>
                                                        <p>Secondary Photo</p>
                                                       </div>
                                                    </div>
                                                 
                                                </div>
                                             
                                            </div>
                                            <div class="tab-pane sapestebpanr" id="3b">
                                                
                                                <div class="row pt-1 pb-1">
                                                    <div class="col-lg-6">
                                                        <div class="d-flex jumbotron flex-column text-info text-center justify-content-around w-100 imgshape bg-white">
                                                            <i class="fa-regular fa-image " style="font-size: 31px;
                                                            color: #a7a7a7;"></i>
                                                        <p>Main Photo</p>
                                                      </div>
                                                        
                                                      <div class="d-flex jumbotron flex-column text-info text-center justify-content-around w-100 imgshape bg-white">
                                                        <i class="fa-regular fa-image " style="font-size: 31px;
                                                        color: #a7a7a7;"></i>
                                                            <p>Secondary Photo</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <div class="detail w-100 bg-white h-100 pl-3 pt-4 ">
                                                            <table>
                                                               <tbody style="font-size: 12px;">
                                                                <tr>
                                                                   <td>
                                                                    <strong> Name: </strong> Kangan
                                                                   </td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Group: </strong> Gold</td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Category: </strong> Gold categary</td>
                                                                </tr>
                                                               
                                                                <tr>
                                                                    <td>
                                                                        <strong> Selling Price: </strong> $22
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Purchase Price: </strong> $30</td>
                                                                </tr>
                                                                <tr>
                                                                   <td> <strong> Description: </strong> Lorem ipsum dolor, sit amet consectetur adipisicing elit. </td>
                                                                </tr>
                                                               </tbody>
                                                            
                                                            </table>
                                                           
                                                           
                                                        </div>
                                                    </div>
                                                </div>
                                              
                                            </div>
                                            <div class="tab-pane sapestebpanr" id="4b">
                                               
                                                <div class="row pt-1 pb-1">
                                                    <div class="col-lg-12">
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <div class="d-flex jumbotron flex-column text-info text-center justify-content-around w-100 imgshape bg-white">
                                                                    <i class="fa-regular fa-image " style="font-size: 31px;
                                                                    color: #a7a7a7;"></i>
                                                                    <p>Main Photo</p>
                                                                </div>
                                                            </div>
                                                            <div class="col-6">
                                                                <div class="d-flex jumbotron flex-column text-info text-center justify-content-around w-100 imgshape bg-white">
                                                                    <i class="fa-regular fa-image " style="font-size: 31px;
                                                                    color: #a7a7a7;"></i>
                                                                <p>Secondary Photo</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <div class="detail bg-white pt-3 pl-2" style="height: 67px;">
                                                            <table>
                                                                <thead style="font-size: 11px;">
                                                                    <tr>
                                                                        <th>Name </td>
                                                                        <th> Group</td>
                                                                        <th class="pr-1"> Category</td>
                                                                        <th class="pr-1">Sell Price </td>
                                                                        <th> Purchase Price</td>
                                                                    </tr>
                                                                </thead>
                                                                <tbody style="font-size: 11px;">
                                                                    <tr>
                                                                        <td> Kangan</td>
                                                                        <td> Gold</td>
                                                                        <td> Gold Category</td>
                                                                        <td> $22</td>
                                                                        <td> $30</td>
                                                                        
                                                                    </tr>
                                                                </tbody>
                                                               
                                                            
                                                            </table>
                                                           
                                                           
                                                        </div>
                                                    </div>
                                                </div>
                                               
                                            </div>
                                            <div class="tab-pane sapestebpanr" id="5b">
                                              
                                                <div class="row  pt-1 pb-1">
                                                    <div class="col-lg-12">
                                                        <div class="detail bg-white pt-3 pl-2" style="height: 67px;">
                                                            <table>
                                                                <thead style="font-size: 11px;">
                                                                    <tr>
                                                                        <th>Name </td>
                                                                        <th> Group</td>
                                                                        <th class="pr-1"> Category</td>
                                                                        <th class="pr-1">Sell Price </td>
                                                                        <th> Purchase Price</td>
                                                                    </tr>
                                                                </thead>
                                                                <tbody style="font-size: 11px;">
                                                                    <tr>
                                                                        <td> Kangan</td>
                                                                        <td> Gold</td>
                                                                        <td> Gold Category</td>
                                                                        <td> $22</td>
                                                                        <td> $30</td>
                                                                        
                                                                    </tr>
                                                                </tbody>
                                                               
                                                            
                                                            </table>
                                                           
                                                           
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-12 mt-4">
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <div class="d-flex jumbotron flex-column text-info text-center justify-content-around w-100 imgshape bg-white">
                                                                    <i class="fa-regular fa-image " style="font-size: 31px;
                                                                    color: #a7a7a7;"></i>
                                                                    <p>Main Photo</p>
                                                                </div>
                                                            </div>
                                                            <div class="col-6">
                                                                <div class="d-flex jumbotron flex-column text-info text-center justify-content-around w-100 imgshape bg-white">
                                                                    <i class="fa-regular fa-image " style="font-size: 31px;
                                                                    color: #a7a7a7;"></i>
                                                                <p>Secondary Photo</p>
                                                               </div>
                                                            </div>
                                                        </div>
                                                       
                                                    </div>
                                                    
                                                </div>
                                              
                                            </div>
                                        
    
    
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="d-flex justify-content-between w-100 ">
                    <button type="button" class="badge border-0 col-3 badge-light-dark p-2" data-dismiss="modal">Cancel</button>
                    <button type="button" class="badge border-0 col-3 bg-dark p-2" data-dismiss="modal">Done</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- container -->
<style>
    #priviewmodel {
        background: #2525252b;
    }

    #priviewmodel .priview-diloge {
        position: fixed;
        right: 0;
        margin: auto;
        width: 427px;
        height: 100%;
        -webkit-transform: translate3d(0%, 0, 0);
        -ms-transform: translate3d(0%, 0, 0);
        -o-transform: translate3d(0%, 0, 0);
        transform: translate3d(0%, 0, 0);
    }

    #priviewmodel .modal-content {
        height: 100%;
        overflow-y: auto;

    }

    .modal.right .modal-body {
        padding: 15px 15px 80px;
    }

    .modal.right.fade .modal-dialog {
        left: -320px;
        -webkit-transition: opacity 0.3s linear, left 0.3s ease-out;
        -moz-transition: opacity 0.3s linear, left 0.3s ease-out;
        -o-transition: opacity 0.3s linear, left 0.3s ease-out;
        transition: opacity 0.3s linear, left 0.3s ease-out;
    }

    .modal.right.fade.show .modal-dialog {
        right: 0;
    }

    /* ----- MODAL STYLE ----- */
    .modal-content {
        border-radius: 0;
        border: none;
    }

    .modal-header {
        border-bottom-color: #eeeeee;
        background-color: #fafafa;
    }

    /* ----- v CAN BE DELETED v ----- */
</style>
