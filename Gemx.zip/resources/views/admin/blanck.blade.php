@extends('admin.layout.main')

@section('content')
<div class="layout-px-spacing">

    <div class="page-header">
        <div class="page-title">
            <h3>Sales Dashboard</h3>
        </div>
        
        <div class="toggle-switch">
           
        </div>
    </div>

    <div class="row layout-top-spacing">

        <div class="col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
            
        </div>

        <div class="col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
            
        </div>

    </div>



</div>
@endsection
@section('script')

@endsection
