<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Buyerquotation extends Model
{ 
    protected $table = 'buyer_quotations';
    use HasFactory;
}
